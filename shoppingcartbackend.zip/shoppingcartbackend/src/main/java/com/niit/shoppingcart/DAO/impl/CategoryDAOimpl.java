package com.niit.shoppingcart.DAO.impl;
import java.util.Locale.Category;
import java.util.List;
import com.niit.shoppingcart.DAO.CategoryDAO;
import com.niit.shoppingcart.model.category;

public class CategoryDAOimpl implements CategoryDAO {
	public boolean save(Category category){
		return false;
	}

	public boolean update(Category category){
		return false;
	}
	public boolean delete(Category category){
		return false;
	}
	public Category get(String id){
		return null;
	}
	public List <Category> List(){
		return null;
	}
  }

  

