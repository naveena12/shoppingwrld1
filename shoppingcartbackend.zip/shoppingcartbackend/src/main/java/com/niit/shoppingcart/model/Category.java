package com.niit.shoppingcart.model;

public class Category {
	//id,name,description
	//These property names better to take same name as fields names
	//in the category table
	private String id;
	//Column(name="name") //optional if the property name in this class
	//same as field name in the table
	
	private String name;
	//Column(name="description") //optional
	private String description;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	}

}
