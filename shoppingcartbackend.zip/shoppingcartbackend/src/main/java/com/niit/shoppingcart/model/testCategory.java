package com.niit.shoppingcart.model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class testCategory {
   public static void main(String[]args){
	   @SuppressWarnings("resource")
	   AnnotationConfigApplicationContext Context=new AnnotationConfigApplicationContext();
	   Context.scan("com.niit.shoppingcart.model");
	   Context.refresh();
	   Context.getBean("category");
	   System.out.println("category instance is created successfully");
   }
}
